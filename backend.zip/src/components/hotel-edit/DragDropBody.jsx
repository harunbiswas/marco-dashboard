import axios from "axios";
import Cookies from "js-cookie";
import { FileUploader } from "react-drag-drop-files";
import { AiFillDelete } from "react-icons/ai";
import { BsUpload } from "react-icons/bs";
import values from "../../../values";

export default function DrapDropBody({ urlSet, url }) {
  const token = Cookies.get("login") && JSON.parse(Cookies.get("login")).token;
  const fileTypes = ["JPG", "PNG", "GIF"];
  // const [url, setUrl] = useState("");
  const fileHandler = (e) => {
    const file = e.target.files[0];
    const formData = new FormData();

    if (file && token) {
      formData.append("image", file);

      axios
        .post(`${values.url}/image`, formData, {
          headers: {
            token,
          },
        })
        .then((d) => {
          urlSet(d.data.url);
        })
        .catch((e) => {
          console.log(e);
        });
    } else {
      urlSet(null);
    }
  };

  return (
    <div className="drag-drop-body">
      {url && (
        <button onClick={() => urlSet("")} className="close">
          <AiFillDelete />
        </button>
      )}
      {(url && <img src={url} alt="" />) || (
        <>
          <div className="icon">
            <BsUpload />
          </div>
          <span>
            Drag & drop files or <label htmlFor="img"> Browse files</label>
          </span>

          <p>JPG, PNG or GIF - Max file size 2MB</p>
        </>
      )}
      <FileUploader
        handleChange={fileHandler}
        name="file"
        className="upload"
        types={fileTypes}
      />
      <input
        onChange={(e) => fileHandler(e)}
        type="file"
        accept="image/*"
        id="img"
      />
    </div>
  );
}
