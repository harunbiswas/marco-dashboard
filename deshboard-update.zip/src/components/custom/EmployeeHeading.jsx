const EmployeeHeading = () => {
  return (
    <div className="heading">
      <h1 className="jakarta">Employee List</h1>
      <p>
        Contrary to popular belief, Lorem Ipsum is not simply random text. It
        has roots in a piece
      </p>
    </div>
  );
};

export default EmployeeHeading;
