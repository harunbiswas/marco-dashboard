export default function PopupTitle({ title }) {
  return <h4 className="popup-title">{title}</h4>;
}
