export default function TextArea() {
  return <textarea name="" placeholder="Weite here"></textarea>;
}
